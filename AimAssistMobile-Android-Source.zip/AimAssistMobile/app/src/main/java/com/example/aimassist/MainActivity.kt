package com.example.aimassist

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

private val Bg = Color(0xFF090A0D)
private val Panel = Color(0xFF15171D)
private val Red = Color(0xFFFF3048)
private val Muted = Color(0xFF9297A3)
private val White = Color(0xFFF4F5F7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AimAssistApp() }
    }
}

@Composable
fun AimAssistApp() {
    var tab by remember { mutableStateOf(0) }
    var sensitivity by remember { mutableFloatStateOf(1.25f) }
    var crosshairSize by remember { mutableFloatStateOf(14f) }
    var gap by remember { mutableFloatStateOf(5f) }
    var selectedColor by remember { mutableStateOf(Red) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Red, background = Bg, surface = Panel,
            onBackground = White, onSurface = White
        )
    ) {
        Column(
            Modifier.fillMaxSize().background(Bg).padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(24.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Red, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                    Text("A", color = White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("AIM ASSIST", color = White, fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                    Text("MOBILE TRAINING LAB", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                }
                Spacer(Modifier.weight(1f))
                Text("v1.0", color = Muted, fontSize = 12.sp)
            }
            Spacer(Modifier.height(24.dp))
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(5.dp)) {
                TabButton("НАСТРОЙКИ", tab == 0, Modifier.weight(1f)) { tab = 0 }
                TabButton("ТРЕНАЖЁР", tab == 1, Modifier.weight(1f)) { tab = 1 }
            }
            Spacer(Modifier.height(20.dp))
            if (tab == 0) {
                Text("ПАРАМЕТРЫ ПРИЦЕЛА", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(12.dp))
                CardPanel {
                    Text("Предпросмотр", color = Muted, fontSize = 12.sp)
                    Box(Modifier.fillMaxWidth().height(150.dp).background(Color(0xFF0D0F14), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                        Crosshair(selectedColor, crosshairSize, gap)
                    }
                    Spacer(Modifier.height(16.dp))
                    SettingSlider("Чувствительность", sensitivity, 0.1f..3f, "%.2f×".format(sensitivity)) { sensitivity = it }
                    SettingSlider("Размер прицела", crosshairSize, 6f..28f, "${crosshairSize.toInt()} px") { crosshairSize = it }
                    SettingSlider("Расстояние между линиями", gap, 1f..12f, "${gap.toInt()} px") { gap = it }
                    Text("ЦВЕТ ПРИЦЕЛА", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        listOf(Red, Color(0xFF35E58B), Color(0xFF42B7FF), Color.White, Color(0xFFFFD447)).forEach { color ->
                            Box(
                                Modifier.size(30.dp).background(color, CircleShape)
                                    .clickable { selectedColor = color },
                                contentAlignment = Alignment.Center
                            ) {
                                if (selectedColor == color) Text("✓", color = Color.Black, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("Настройки предназначены для ручного переноса в игру. Приложение не управляет Standoff 2.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
            } else {
                TrainerScreen()
            }
            Spacer(Modifier.weight(1f))
            Text("AIM ASSIST  •  TRAIN SMART", Modifier.align(Alignment.CenterHorizontally).padding(bottom = 14.dp), color = Color(0xFF555B66), fontSize = 10.sp, letterSpacing = 1.4.sp)
        }
    }
}

@Composable
fun TabButton(label: String, active: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(modifier.height(42.dp).background(if (active) Red else Color.Transparent, RoundedCornerShape(10.dp)).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Text(label, color = White, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
    }
}

@Composable
fun CardPanel(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
}

@Composable
fun SettingSlider(title: String, value: Float, range: ClosedFloatingPointRange<Float>, valueText: String, onValue: (Float) -> Unit) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = White, fontSize = 13.sp)
            Spacer(Modifier.weight(1f))
            Text(valueText, color = Red, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Slider(value = value, onValueChange = onValue, valueRange = range, colors = SliderDefaults.colors(thumbColor = Red, activeTrackColor = Red, inactiveTrackColor = Color(0xFF353943)))
    }
}

@Composable
fun Crosshair(color: Color, size: Float, gap: Float) {
    Canvas(Modifier.size(100.dp)) {
        val c = Offset(this.size.width / 2, this.size.height / 2)
        val scale = size / 14f
        val g = gap * scale
        val len = 15f * scale
        val stroke = 2.5f * scale
        listOf(
            Offset(c.x, c.y - g - len) to Offset(c.x, c.y - g),
            Offset(c.x, c.y + g) to Offset(c.x, c.y + g + len),
            Offset(c.x - g - len, c.y) to Offset(c.x - g, c.y),
            Offset(c.x + g, c.y) to Offset(c.x + g + len, c.y)
        ).forEach { (a, b) -> drawLine(color, a, b, strokeWidth = stroke, cap = StrokeCap.Round) }
        drawCircle(color, radius = 2.2f * scale, center = c)
    }
}

@Composable
fun TrainerScreen() {
    var started by remember { mutableStateOf(false) }
    var targetVisible by remember { mutableStateOf(false) }
    var hits by remember { mutableIntStateOf(0) }
    var attempts by remember { mutableIntStateOf(0) }
    var reaction by remember { mutableLongStateOf(0L) }
    var shownAt by remember { mutableLongStateOf(0L) }
    var x by remember { mutableFloatStateOf(0.5f) }
    var y by remember { mutableFloatStateOf(0.5f) }

    LaunchedEffect(started, attempts) {
        if (started && attempts < 10) {
            targetVisible = false
            delay(Random.nextLong(700, 1700))
            x = Random.nextFloat() * 0.72f + 0.14f
            y = Random.nextFloat() * 0.65f + 0.17f
            shownAt = System.currentTimeMillis()
            targetVisible = true
        } else if (attempts >= 10) {
            started = false
            targetVisible = false
        }
    }

    Text("ТРЕНИРОВКА РЕАКЦИИ", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StatCard("ПОПАДАНИЯ", "$hits / $attempts", Modifier.weight(1f))
        StatCard("ПОСЛЕДНЯЯ РЕАКЦИЯ", if (reaction == 0L) "—" else "${reaction} мс", Modifier.weight(1f))
    }
    Spacer(Modifier.height(14.dp))
    BoxWithConstraints(Modifier.fillMaxWidth().weight(1f).background(Color(0xFF101218), RoundedCornerShape(18.dp))) {
        if (targetVisible) {
            Box(
                Modifier.offset(x = maxWidth * x - 18.dp, y = maxHeight * y - 18.dp)
                    .size(36.dp)
                    .background(Red, CircleShape)
                    .clickable {
                        reaction = System.currentTimeMillis() - shownAt
                        hits++
                        attempts++
                        targetVisible = false
                    },
                contentAlignment = Alignment.Center
            ) {
                Box(Modifier.size(14.dp).background(Color.White, CircleShape))
            }
            Text("НАЖМИ НА ЦЕЛЬ", Modifier.align(Alignment.BottomCenter).padding(14.dp), color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
        } else {
            Text(if (started) "Приготовься…" else "Нажми «Старт», чтобы начать", Modifier.align(Alignment.Center), color = Muted, fontSize = 13.sp)
        }
        if (!started && attempts >= 10) {
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("СЕССИЯ ЗАВЕРШЕНА", color = White, fontWeight = FontWeight.Bold)
                Text("Попадания: $hits из 10", color = Red, fontSize = 13.sp)
            }
        }
    }
    Spacer(Modifier.height(14.dp))
    Button(
        onClick = {
            if (!started) { hits = 0; attempts = 0; reaction = 0; started = true }
            else { started = false; targetVisible = false }
        },
        modifier = Modifier.fillMaxWidth().height(52.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Red),
        shape = RoundedCornerShape(13.dp)
    ) {
        Text(if (started) "ОСТАНОВИТЬ" else if (attempts >= 10) "ЕЩЁ РАЗ" else "СТАРТ", fontWeight = FontWeight.Black, letterSpacing = 1.sp)
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(14.dp)).padding(14.dp)) {
        Text(title, color = Muted, fontSize = 9.sp, letterSpacing = 0.8.sp)
        Spacer(Modifier.height(6.dp))
        Text(value, color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}
