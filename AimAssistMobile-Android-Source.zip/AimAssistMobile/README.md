# Aim Assist Mobile

Android starter project built with Kotlin and Jetpack Compose.

## Open and run
1. Install Android Studio (current stable).
2. Choose **Open** and select this `AimAssistMobile` folder.
3. Let Gradle sync complete.
4. Run the `app` configuration on an Android device or emulator.

## Included
- Dark red/black UI
- Crosshair preview with size, gap, color and sensitivity controls
- Reaction trainer with 10 targets and basic hit/response stats

## Scope
This is a standalone training/settings companion. It does not read, modify, overlay, or control Standoff 2, and it does not automate aiming in online matches.
